<?php

$conn = mysqli_connect('localhost','root','','contact_db') or die('connection failed');

if(isset($_POST['submit'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $number = $_POST['number'];
   $date = $_POST['date'];

   $insert = mysqli_query($conn, "INSERT INTO `contact_form`(name, email, number, date) VALUES('$name','$email','$number','$date')") or die('query failed');

   if($insert){
      $message[] = 'appointment made successfully!';
   }else{
      $message[] = 'appointment failed';
   }

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Health predictor</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    
<!-- header section starts  -->

<header class="header">

    <a href="#" class="logo"> <i class="fas fa-heartbeat"></i> <strong>HealthHub</strong>360 </a>

    <nav class="navbar">
        <a href="#home">home</a>
        <a href="#about">about</a>
        <a href="#services">services</a>
        <a href="#doctors">doctors</a>
        <a href="#appointment">appointment</a>
        <a href="#review">review</a>
        <!-- <a href="#blogs">blogs</a> -->
    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>

</header>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home" id="home">

    <div class="image">
        <img src="image/home.jpg" alt="">
    </div>

    <div class="content">
        <h3>we take care of your healthy life</h3>
        <p> A person who has good physical health is likely to have bodily functions and processes working at their peak.</p>
        <a href="#appointment" class="btn"> appointment us <span class="fas fa-chevron-right"></span> </a>
    </div>

</section>

<!-- home section ends -->

<!-- icons section starts  -->

<section class="icons-container">

    <div class="icons">
        <i class="fas fa-user-md"></i>
        <h3>20+</h3>
        <p>doctors at work</p>
    </div>

    <div class="icons">
        <i class="fas fa-users"></i>
        <h3>1030+</h3>
        <p>satisfied patients</p>
    </div>

    <div class="icons">
        <i class="fas fa-procedures"></i>
        <h3>200+</h3>
        <p>bed facility</p>
    </div>

    
</section>

<!-- icons section ends -->

<!-- about section starts  -->

<section class="about" id="about">

    <h1 class="heading"> <span>about</span> us </h1>

    <div class="row">

        <div class="image">
            <img src="image/about.png" alt="">
        </div>

        <div class="content">
            <h3>take the world's best quality treatment</h3>
             <p>Welcome to My Health Care Center, a beacon of healthcare excellence since 2012.
                 Committed to compassionate, cutting-edge care, we offer a wide range of medical
                 services in state-of-the-art facilities. Our dedicated team strives for the best 
                 in patient outcomes,community health, and innovative medical practices.</p>
            <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
        </div>

    </div>

</section>

<!-- about section ends -->

<!-- services section starts  -->

<section class="services" id="services">

    <h1 class="heading"> our <span>services</span> </h1>

    <div class="box-container">

        <div class="box">
            <i class="fas fa-notes-medical"></i>
            <h3>free checkups</h3>
            <a href="heart_disease.php" class="btn">Heart Disease Prediction <span class="fas fa-chevron-right"></span></a>
        </div>

        <div class="box">
            <i class="fas fa-notes-medical"></i>
            <h3>free checkups</h3>
            <a href="diabetes.php" class="btn">Diabetes Prediction <span class="fas fa-chevron-right"></span></a>
        </div>

        <!-- <div class="box">
            <i class="fas fa-notes-medical"></i>
            <h3>free checkups</h3>
            <a href="cancer.php" class="btn">Cancer Prediction <span class="fas fa-chevron-right"></span></a>
        </div> -->

        <div class="box">
            <i class="fas fa-pills"></i>
            <h3>Ayurveda</h3>
            <a href="https://ayushkitchen.com/about-us-3/" class="btn"> Swtich to Ayurveda <span class="fas fa-chevron-right"></span> </a>
        </div>

        <div class="box">
            <i class="fas fa-user-md"></i>
            <h3>Yoga </h3>
            <a href="yoga/index.php" class="btn"> Switch to Yoga <span class="fas fa-chevron-right"></span> </a>
        </div>

        <div class="box">
            <i class="fas fa-heartbeat"></i>
            <h3>total care</h3>
            <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
        </div>

    </div>

</section>

<!-- services section ends -->



<!-- doctors section starts  -->

<section class="doctors" id="doctors">

    <h1 class="heading"> our <span>doctors</span> </h1>

    <div class="box-container">

        <div class="box">
            <img src="image/dr.jpeg" alt="">
            <h3>Dr. Subhash Yadav	</h3>
            <span>expert doctor</span>
            <div class="share">
            <a href="https://www.facebook.com/share/51EVwWdcnJx5xkW3/?mibextid=qi2Omg" class="fab fa-facebook-f"></a>
                <a href="https://www.instagram.com/idrsubhashyadav?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==/" class="fab fa-twitter"></a>
                <a href="https://www.instagram.com/idrsubhashyadav?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" class="fab fa-instagram"></a>
                <a href="https://www.instagram.com/idrsubhashyadav?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" class="fab fa-linkedin"></a>
                
            </div>
        </div>

        <!-- <div class="box">
            <img src="image/d2.jpg" alt="">
            <h3>Dr. Pawan Sharma</h3>
            <span>expert doctor</span>
            <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/d3.jpg" alt="">
            <h3>Dr. Sunita Kothari</h3>
            <span>expert doctor</span>
            <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/d4.jpg" alt="">
            <h3>Dr. Riya Yadav</h3>
            <span>expert doctor</span>
            <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/d5.jpg" alt="">
            <h3>Dr. Rishav Bansal</h3>
            <span>expert doctor</span>
            <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/d6.jpeg" alt="">
            <h3>Dr R N Khan</h3>
            <span>expert doctor</span>
            <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            
            </div>
        </div> -->
        
    </div>

</section>

<!-- doctors section ends -->

<!-- appointmenting section starts   -->

<section class="appointment" id="appointment">

    <h1 class="heading"> <span>appointment</span> now </h1>    

    <div class="row">

        <div class="image">
            <img src="image/appointment-img.svg" alt="">
        </div>

        <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
        <?php
            if(isset($message)) {
                foreach($message as $message) {
                echo'<p class ="message">'.$message.'</p>';
            }
            }
        ?>
      
            <h3>make appointment</h3>
            <input type="text"name="name" placeholder="your name" class="box">
            <input type="number"name="number" placeholder="your number" class="box">
            <input type="email"name="email" placeholder="your email" class="box">
            <input type="date"name="date" class="box">
            <input type="submit" name="submit" value="appointment now" class="btn">
        </form>

    </div>

</section>

<!-- appointmenting section ends -->

<!-- review section starts  -->

<section class="review" id="review">
    
    <h1 class="heading"> client's <span>review</span> </h1>

    <div class="box-container">

        <div class="box">
            <img src="image/sunny.jpg" alt="">
            <h3>Sunny</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p class="text">I recently had a surgery at SNS Hospital and was thoroughly impressed by the 
                professionalism and kindness of all the staff. From the surgeons to the nurses, everyone
                 was attentive and caring. The facilities were clean and well-maintained, making my recovery 
                 as comfortable as possible. They also had a very efficient appointment system, which minimized 
                 waiting times. I felt well-informed throughout my treatment, thanks to the clear communication
                  from the doctors. Highly recommend SNS for anyone in need of high-quality medical care</p>
        </div>

        <div class="box">
            <img src="image/shubham_pic.jpeg" alt="">
            <h3>Shubham</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p class="text">My experience at SNS Hospital was beyond expectations. The emergency
                 department was quick to respond when I needed urgent care, and the staff was incredibly
                  supportive throughout my stay. The hospital is equipped with modern technology which 
                  helped in precise diagnosis and effective treatment. The environment was also very comforting,
                   which is essential during stressful times. I am grateful for the care provided 
                and would definitely suggest this hospital for its excellent services!</p>
        </div>

        <div class="box">
            <img src="image/hithart.jpg" alt="">
            <h3>Hithart</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p class="text">Visiting SNS Hospital was reassuring during a difficult time. 
                The pediatric care my child received was outstanding, with doctors and nurses
                 who genuinely care about their little patients. The rooms were child-friendly 
                 and helped ease my son's fears. Communication was clear, and all our concerns
                  were addressed with patience and expertise.
                 It’s comforting to know we have such a reliable healthcare option nearby!</p>
        </div>

    </div>

</section>


<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href="#home"> <i class="fas fa-chevron-right"></i> home </a>
            <a href="#about"> <i class="fas fa-chevron-right"></i> about </a>
            <a href="#services"> <i class="fas fa-chevron-right"></i> services </a>
            <a href="#doctors"> <i class="fas fa-chevron-right"></i> doctors </a>
            <a href="#appointment"> <i class="fas fa-chevron-right"></i> appointment </a>
            <a href="#review"> <i class="fas fa-chevron-right"></i> review </a>
            <!-- <a href="#blogs"> <i class="fas fa-chevron-right"></i> blogs </a> -->
        </div>

        <div class="box">
            <h3>our services</h3>
            <a href="#"> <i class="fas fa-chevron-right"></i> dental care </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> message therapy </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> cardioloty </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> diagnosis </a>
            <!-- <a href="#"> <i class="fas fa-chevron-right"></i> ambulance service </a> -->
        </div>

        <div class="box">
            <h3>appointment info</h3>
            <a href="#"> <i class="fas fa-phone"></i> +91 6236756734 </a>
            <a href="#"> <i class="fas fa-phone"></i> +91 9799299123 </a>
            <a href="#"> <i class="fas fa-envelope"></i> smyadav@gmail.com </a>
            <a href="#"> <i class="fas fa-envelope"></i> sns@gmail.com </a>
            <a href="#"> <i class="fas fa-map-marker-alt"></i> Chomu Jaipur </a>
        </div>

        <div class="box">
            <h3>follow us</h3>
            <a href="#"> <i class="fab fa-faceappointment-f"></i> faceappointment </a>
            <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
            <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
            <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
            <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
            <a href="#"> <i class="fab fa-pinterest"></i> pinterest </a>
        </div>

    </div>

    <div class="credit"> created by <span>Shubham Yadav</span> | all rights reserved </div>

</section>

<!-- footer section ends -->


<!-- js file link  -->
<script src="js/script.js"></script>

</body>
</html>

