<?php

$conn = mysqli_connect('localhost','root','','yoga') or die('connection failed');

if(isset($_POST['submit'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $number = $_POST['number'];
   $date = $_POST['date'];

   $insert = mysqli_query($conn, "INSERT INTO 'appointment'(name, email, number, date) VALUES('$name','$email','$number','$date')") or die('query failed');

   if($insert){
      $message[] = 'appointment made successfully!';
   }else{
      $message[] = 'appointment failed';
   }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Fitness & Nutrition</title>

  <!-- 
    - favicon
  -->
  <link rel="shortcut icon" href="./favicon.svg" type="image/svg+xml">

  <!-- 
    - custom css link
  -->
  <link rel="stylesheet" href="./assets/css/style.css">

  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Playfair+Display:wght@600&display=swap"
    rel="stylesheet">
</head>

<body id="top">

  <!-- 
    - #HEADER
  -->

  <header class="header" data-header>
    <div class="container">

      <a href="#" class="logo">
        Fitness<span class="span">.</span>
      </a>

      <nav class="navbar" data-navbar>

        <button class="nav-toggle-btn" aria-label="close menu" data-nav-toggler>
          <ion-icon name="close-outline" aria-hidden="true"></ion-icon>
        </button>

        <ul class="navbar-list">

          <li class="navbar-item">
            <a href="#home" class="navbar-link" data-nav-link>Home</a>
          </li>

          <li class="navbar-item">
            <a href="#about" class="navbar-link" data-nav-link>About Us</a>
          </li>

          <li class="navbar-item">
            <a href="#tips" class="navbar-link" data-nav-link>Tips</a>
          </li>

          <li class="navbar-item">
            <a href="#blog" class="navbar-link" data-nav-link>Blog</a>
          </li>

          <li class="navbar-item">
            <a href="#" class="navbar-link" data-nav-link>Contact</a>
          </li>

        </ul>

      </nav>

      <!-- <a href="#" class="btn btn-primary">Sign Up</a> -->

      <button class="nav-toggle-btn" aria-label="open manu" data-nav-toggler>
        <ion-icon name="menu-outline" aria-hidden="true"></ion-icon>
      </button>

      <div class="overlay" data-nav-toggler data-overlay></div>

    </div>
  </header>





  <main>
    <article>

      <!-- 
        - #HERO
      -->

      <section class="section hero" aria-label="hero" id="home" data-section
        style="background-image: url('./assets/images/hero-banner.jpg')">
        <div class="container">

          <p class="hero-subtitle">Fitness & Nutrition</p>

          <h1 class="h1 hero-title">This life style for your fitness, not only diet.</h1>

          <p class="hero-text">
            It has survived not only five centuries but also
          </p>

          <a href="#" class="btn btn-secondary">Start Course</a>

          <div class="social-wrapper">

            <p class="social-title">Connect with us:</p>

            <ul class="social-list">

              <li>
                <a href="https://www.facebook.com/share/51EVwWdcnJx5xkW3/?mibextid=qi2Omg" class="social-link">
                  <ion-icon name="logo-facebook"></ion-icon>
                </a>
              </li>

              <li>
                <a href="https://www.instagram.com/idrsubhashyadav?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" class="social-link">
                  <ion-icon name="logo-instagram"></ion-icon>
                </a>
              </li>

              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-twitter"></ion-icon>
                </a>
              </li>

              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-linkedin"></ion-icon>
                </a>
              </li>

            </ul>

          </div>

        </div>
      </section>





      <!-- 
        - #SERVICE
      -->

      <section class="section service" aria-label="service" data-section>
        <div class="container">

          <ul class="grid-list">

            <li>
              <div class="service-card">

                <div class="card-icon">
                  <img src="./assets/images/service-1.svg" width="60" height="60" loading="lazy" alt="Women’s Course">
                </div>

                <h3 class="h3">
                  <a href="https://www.youtube.com/playlist?list=PLPs1jhlpr_3KM0Hcxl3wAymrm1nH31Ijv" class="card-title">Women’s Course</a>
                </h3>

                <a href="https://www.youtube.com/playlist?list=PLPs1jhlpr_3KM0Hcxl3wAymrm1nH31Ijv" class="btn btn-secondary">
                  <ion-icon name="arrow-forward"></ion-icon>
                </a>

              </div>
            </li>

            <li>
              <div class="service-card active">

                <div class="card-icon">
                  <img src="./assets/images/service-2.svg" width="60" height="60" loading="lazy" alt="Basic Course">
                </div>

                <h3 class="h3">
                  <a href="https://www.youtube.com/watch?v=fqYAOr6LFqM" class="card-title">Basic Course</a>
                </h3>
                <a href="https://www.youtube.com/watch?v=fqYAOr6LFqM" class="btn btn-secondary">
                  <ion-icon name="arrow-forward"></ion-icon>
                </a>

              </div>
            </li>

            <li>
              <div class="service-card">

                <div class="card-icon">
                  <img src="./assets/images/service-3.svg" width="60" height="60" loading="lazy" alt="Men’s Course">
                </div>

                <h3 class="h3">
                  <a href="https://www.youtube.com/playlist?list=PLBfRLLhSBb-B8-1v35ueWDRaZtyr_boHN" class="card-title">Men’s Course</a>
                </h3>

                <a href="https://www.youtube.com/playlist?list=PLBfRLLhSBb-B8-1v35ueWDRaZtyr_boHN" class="btn btn-secondary">
                  <ion-icon name="arrow-forward"></ion-icon>
                </a>

              </div>
            </li>

          </ul>

        </div>
      </section>





      <!-- 
        - #ABOUT
      -->

      <section class="section about" aria-label="about" id="about" data-section>
        <div class="container">

          <div class="about-banner img-holder" style="--width: 470; --height: 580;">
            <img src="./assets/images/yogaa.jpeg" width="470" height="580" loading="lazy" alt="about banner"
              class="img-cover">

            <a href="#" class="btn btn-secondary">Meet Instructor</a>
          </div>

          <div class="about-content">

            <h2 class="h2 section-title">We have expert instructor for help our students.</h2>

            <p class="section-text">
              Our mission is to empower our community through the practice of yoga. We aim to provide
               high-quality yoga instruction that is accessible to everyone, regardless of their 
               experience level. We focus on the holistic benefits of yoga, which include physical
                health, mental clarity, and emotional well-being.
            </p>


          </div>

        </div>
      </section>





      <!-- 
        - #COUR
      -->

        <section class="yoga-tips" id="tips">
        <h2>Yoga Tips for Better Health</h2>
        <div class="tips-container">
            <div class="tip">
                <h3>Start Your Day with Sun Salutations</h3>
                <p>Beginning your day with a few rounds of Sun Salutations (Surya Namaskar) can energize your body and set a positive tone for the rest of your day. This sequence of movements improves circulation and flexibility.</p>
            </div>
            <div class="tip">
                <h3>Focus on Your Breath</h3>
                <p>Practicing mindful breathing (Pranayama) during your yoga sessions can improve your concentration, relieve stress, and calm your mind.</p>
            </div>
            <!-- Add more tips as needed -->
        </div>
      </section>

      <section class="meditation-tips">
        <h2>Meditation Tips for Mindful Living</h2>
        <div class="tips-container">
            <div class="tip">
                <h3>Find a Quiet Space</h3>
                <p>Choose a calm and quiet space for your meditation sessions to help reduce distractions and enhance your focus. A dedicated meditation area can also set the right mood.</p>
            </div>
            <div class="tip">
                <h3>Be Consistent</h3>
                <p>Consistency is key. Try to meditate at the same time each day to establish a routine that sticks and enhances the benefits over time.</p>
            </div>
            <!-- Add more tips as needed -->
        </div>
      </section>



  

      <!-- 
        - #BLOG
      -->

      <section class="section blog" aria-label="blog" id="blog" data-section>
        <div class="container">

          <div class="title-wrapper">
            <p class="section-subtitle">Our Blog Post</p>

            <h2 class="h2 section-title">Latest Article of Nutrition</h2>
          </div>

          <ul class="grid-list">

            <li>
              <div class="blog-card">

                <div class="wrapper">

                  <time class="publish-date" datetime="2024-04-20">
                    <span class="span">20</span> Apr
                  </time>

                  <div>

                    <div class="card-author">
                      <a href="#" class="card-link">
                        By: <span class="span">Dr. Carlos Alvarez</span>
                      </a>
                    </div>


                  </div>

                </div>

                <!-- <h3 class="h3">
                  <a href="#" class="card-title">It was popularised sheets the release contain</a>
                </h3> -->

                <p class="card-text">
                The practice of yoga is inherently mindful, 
                involving focused attention and awareness of the present moment. 
                This mindfulness aspect is pivotal in reducing symptoms of stress, anxiety, 
                and depression. By engaging in mindful yoga, practitioners learn to anchor their 
                attention in the present, cultivating a peaceful mind.
                The practice of yoga is inherently mindful.
          

                </P>

              </div>
            </li>

            <li>
              <div class="blog-card">

                <div class="wrapper">

                  <time class="publish-date" datetime="2024-04-18">
                    <span class="span">18</span> Apr
                  </time>

                  <div>

                    <div class="card-author">
                      <a href="#" class="card-link">
                        By: <span class="span"> Dr. Emily Thompson</span>
                      </a>
                    </div>
 

                  </div>

                </div>

                <!-- <h3 class="h3">
                  <a href="#" class="card-title">It was popularised sheets the release contain</a>
                </h3> -->

                <p class="card-text">
                Emerging research suggests that regular yoga practice can contribute to longer life expectancy by 
                improving vital functions and reducing risk factors associated with aging. Yoga's ability to reduce 
                inflammation, improve heart health, and enhance cellular regeneration are key factors in its anti-aging benefits.
                Yoga's impact on physical health is profound. 
                </p>

              </div>
            </li>

            <li>
              <div class="blog-card">

                <div class="wrapper">

                  <time class="publish-date" datetime="2024-04-25">
                    <span class="span">25</span> Apr
                  </time>

                  <div>

                    <div class="card-author">
                      <a href="#" class="card-link">
                        By: <span class="span">Dr. Anika Mehta</span>
                      </a>
                    </div>

                    <ul class="card-meta-list">
                      <li class="card-meta-item">
                        <p class="item-text">87 Likes</p>
                      </li>

                      <li class="card-meta-item">
                        <p class="item-text">58 Share</p>
                      </li>
                    </ul>

                  </div>

                </div>

                <!-- <h3 class="h3">
                  <a href="#" class="card-title">It was popularised sheets the release contain</a>
                </h3> -->

                <p class="card-text">
                Yoga, a millennia-old practice rooted in the ancient spiritual, philosophical, and cultural traditions of India,
                has transcended its origins to become a global phenomenon prized for its comprehensive health benefits. This article
                 delves into the historical evolution of yoga, examines its various forms, and provides guidance for those embarking 
                 on their yoga journey.
                </p>

              </div>
            </li>

          </ul>

        </div>
      </section>

      <!-- <section class="section contact" aria-label="contact" id="contact" data-section>
        <h2>Contact Us</h2>
    <p>If you have any questions, please feel free to reach out to us!</p> -->
    
    <!-- Booking Form -->
    <!-- <h3>Book a Yoga Session</h3>
    <div class="form-group">
    <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
      <?php
          if(isset($message)){
              foreach($message as $message) {
              echo'<p class ="message">'.$message.'</p>';
          }
          }
      ?>
          <div class="form-group">
            <label for="name">Your Name:</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="email">Email Address:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="number">Phone Number:</label>
            <input type="number" id="number" name="number" required>
        </div>
        <div class="form-group">
            <label for="date">Preferred Date:</label>
            <input type="date" id="date" name="date" required>
        </div>
        <div class="form-group">
            <input type="submit" value="Book Session" name="submit>
        </div>
    </form>
        </div>
           </section>


 -->


  <!-- 
    - #FOOTER
  -->

  <footer class="footer">

    <div class="footer-top section" data-section>
      <div class="container">
        

        <ul class="footer-list">

          <li>
            <p class="footer-list-title">Opening Hours</p>
          </li>

          <li>
            <a href="#" class="footer-link">Mon-Fri: 9 AM – 6 PM</a>
          </li>

          <li>
            <a href="#" class="footer-link">Saturday: 9 AM – 4 PM</a>
          </li>

          <li>
            <a href="#" class="footer-link">Sunday: Closed</a>
          </li>

          <li>
            <p class="footer-list-title address-title">Location</p>
          </li>

          <li>
            <address class="address">
              Sarna industry Area, jaipur<br>
              Rajasthan, 
            </address>
          </li>

        </ul>

      </div>
    </div>

    <div class="footer-bottom">
      <div class="container">

        <p class="copyright">
          &copy; Fitness Made With
          <ion-icon name="heart" aria-hidden="true"></ion-icon> by
          <a href="#" class="copyright-link">Shubahm Yadav</a>
        </p>

        <ul class="footer-bottom-list">

          <li class="footer-bottom-item">
            <a href="#" class="footer-bottom-link">Terms of Service</a>
          </li>

          <li class="footer-bottom-item">
            <a href="#" class="footer-bottom-link">Privacy Policy</a>
          </li>

          <li class="footer-bottom-item">
            <a href="#" class="footer-bottom-link">Sitemap</a>
          </li>

          <li class="footer-bottom-item">
            <a href="#" class="footer-bottom-link">Security</a>
          </li>

        </ul>

      </div>
    </div>

  </footer>





  <!-- 
    - #BACK TO TOP
  -->

  <a href="#top" class="back-top-btn" aria-label="back to top" data-back-top-btn>
    <ion-icon name="chevron-up" aria-hidden="true"></ion-icon>
  </a>





  <!-- 
    - custom js link
  -->
  <script src="./assets/js/script.js" defer></script>

  <!-- 
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>

</html>