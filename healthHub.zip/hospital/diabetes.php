<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diabetes Prediction Form</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* for diabetes predication page */
body {
    font-family: Arial, sans-serif;
}

.container {
    width: 90%;
    max-width: 600px;
    margin: 50px auto;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
}

.form-group input {
    width: 100%;
    padding: 10px;
    font-size: 16px;
}

button {
    padding: 10px 20px;
    font-size: 18px;
    color: white;
    background-color: #007bff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}
    </style>
</head>

<body>
    <div class="container">
        <h1>Diabetes Prediction</h1>
        <form id="predictionForm" action="https://diabetes-da0n.onrender.com/api/predict" method="GET">
            <div class="form-group">
                <label for="glucose">Glucose:</label>
                <input type="number" id="glucose" name="glucose" required>
            </div>
            <div class="form-group">
                <label for="bloodPressure">Blood Pressure:</label>
                <input type="number" id="bloodPressure" name="bloodPressure" required>
            </div>
            <div class="form-group">
                <label for="skinThickness">Skin Thickness:</label>
                <input type="number" id="skinThickness" name="skinThickness" required>
            </div>
            <div class="form-group">
                <label for="insulin">Insulin:</label>
                <input type="number" id="insulin" name="insulin" required>
            </div>
            <div class="form-group">
                <label for="bmi">BMI:</label>
                <input type="number" id="bmi" name="bmi" required>
            </div>
            <div class="form-group">
                <label for="diabetesPedigreeFunction">Diabetes Pedigree Function:</label>
                <input type="number" step="0.01" id="diabetesPedigreeFunction" name="diabetesPedigreeFunction" required>
            </div>
            <div class="form-group">
                <label for="age">Age:</label>
                <input type="number" id="age" name="age" required>
            </div>
            <button type="submit">Predict</button>
        </form>
    </div>
    <script src="script.js"></script>
</body>
</html>
