<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Heart Disease Prediction</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
            /* background: url('your-background-image-url.jpg') no-repeat center center fixed; */
            background-size: cover;
        }
        .main-content {
            padding-top: 60px;
            padding-left: 250px;
        }
        .card {
            background: rgba(255, 255, 255, 0.95);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            max-width: 700px;
            margin: auto;
        }
        h2 {
            color: #0056b3;
            margin-bottom: 20px;
        }
        .btn-primary {
            background-color: #0056b3;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            
        }
    </style>
    
</head>
<body>
<div class="main-content">
    <div class="card">
        <h2 class="text-center">Heart Disease Prediction Form</h2>
        <form action="https://heart-5vtr.onrender.com/api/predict" method="GET" id="predictionForm">
            <!-- Add fields for each input required -->
            <div class="form-group"><label for="age">Age:</label><input type="number" class="form-control" id="age" name="p1" required></div>
            <div class="form-group"><label for="sex">Sex:</label><select class="form-control" id="sex" name="p2"><option value="1">Male</option><option value="0">Female</option></select></div>
            <div class="form-group"><label for="cp">Chest Pain Type (cp):</label><select class="form-control" id="cp" name="p3"><option value="0">Typical angina</option><option value="1">Atypical angina</option><option value="2">Non-anginal pain</option><option value="3">Asymptomatic</option></select></div>
            <div class="form-group"><label for="trestbps">Resting Blood Pressure (trestbps):</label><input type="number" class="form-control" id="trestbps" name="p4" required></div>
            <div class="form-group"><label for="chol">Cholesterol (chol):</label><input type="number" class="form-control" id="chol" name="p5" required></div>
            <div class="form-group"><label for="fbs">Fasting Blood Sugar > 120 mg/dl (fbs):</label><select class="form-control" id="fbs" name="p6"><option value="1">True</option><option value="0">False</option></select></div>
            <div class="form-group"><label for="restecg">Resting Electrocardiographic Results (restecg):</label><select class="form-control" id="restecg" name="p7"><option value="0">Normal</option><option value="1">Having ST-T wave abnormality</option><option value="2">Showing probable or definite left ventricular hypertrophy</option></select></div>
            <div class="form-group"><label for="thalach">Maximum Heart Rate Achieved (thalach):</label><input type="number" class="form-control" id="thalach" name="p8" required></div>
            <div class="form-group"><label for="exang">Exercise Induced Angina (exang):</label><select class="form-control" id="exang" name="p9"><option value="0">No</option><option value="1">Yes</option></select></div>
            <div class="form-group"><label for="oldpeak">ST Depression Induced by Exercise Relative to Rest (oldpeak):</label><input type="number" step="0.1" class="form-control" id="oldpeak" name="p10" required></div>
            <div class="form-group"><label for="slope">The Slope of The Peak Exercise ST Segment (slope):</label><select class="form-control" id="slope" name="p11"><option value="0">Upsloping</option><option value="1">Flat</option><option value="2">Downsloping</option></select></div>
            <div class="form-group"><label for="ca">Number of Major Vessels (0-3) Colored by Flourosopy (ca):</label><input type="number" class="form-control" id="ca" name="p12" required></div>
            <div class="form-group"><label for="thal">Thalassemia (thal):</label><select class="form-control" id="thal" name="p13"><option value="1">Normal</option><option value="2">Fixed Defect</option><option value="3">Reversible Defect</option></select></div>
            <!-- <button type="button" class="btn btn-primary" onclick="makePrediction()">Predict</button> -->
            <button type="submit" class="btn btn-primary">Predict</button>
        </form>
    </div>
</div>

</body>
</html>